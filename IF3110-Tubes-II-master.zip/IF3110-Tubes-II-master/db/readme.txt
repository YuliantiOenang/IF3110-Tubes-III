Gunakan file ruserba.sql sebagai source pembuatan database, BUKAN ruserba_original.sql.
Lakukan create database terlebih dahulu dengan nama database: "ruserba".

Tambahan:
Password untuk user John Smith: "letmein" (dalam database disimpan dalam bentuk MD5)
