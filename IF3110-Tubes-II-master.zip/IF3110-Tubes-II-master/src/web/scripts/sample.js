//window.addEventListener("load", alert("Hello RuSerBa!"));

/*window.addEventListener("load", function() {
	document.getElementById("paragraf").onclick = function()	{
		alert("Ini adalah suatu paragraf Lorem Ipsum.");	
	};
});
*/
