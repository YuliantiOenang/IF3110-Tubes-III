window.addEventListener("load", function() {
	deleteShoppingBag();
});
