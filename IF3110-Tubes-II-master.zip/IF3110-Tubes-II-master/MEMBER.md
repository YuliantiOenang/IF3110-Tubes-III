Data Kelompok
=============

Okaswara Perkasa - 13510051 - 13510051 di std.stei.itb.ac.id - okaswara-p
Sandy Gunawan Tanuwijaya - 13510025 - 13510025 di std.stei.itb.ac.id - 4XPG
