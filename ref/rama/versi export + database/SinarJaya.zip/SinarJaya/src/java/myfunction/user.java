/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package myfunction;

/**
 *
 * @author A46CB
 */
public class user {
    public user() {
        
    }
    public int id;
    public String username;
    public String nama;
    public String nohp;
    public String alamat;
    public String provinsi;
    public String kota;
    public String kodepos;
    public String email;
    public String password;
    public int transaksi;
    public int balance;
    
}
