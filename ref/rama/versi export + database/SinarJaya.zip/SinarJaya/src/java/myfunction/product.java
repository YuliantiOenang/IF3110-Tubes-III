/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package myfunction;

/**
 *
 * @author A46CB
 */
public class product {
    public product() {
        
    }
    
    public int id;
    public String nama;
    public int harga;
    public int sold;
    public int stok;
    public String image;
    public String kategori;
    public String keterangan;
}
